$(document).ready(function () {
  viewprmList = new Array();
  viewprmListExclude = new Array();
  getAllItem();
  getSelectedItem();
  viewprmList = $(viewprmList).not(viewprmListExclude).get();
  makeviewprmList(viewprmList);
  makeviewprmListSelected(viewprmListExclude);

  $("#search-username-input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) {
      return;
    }
    makeviewprmList(viewprmList);
  });

  $("table").on("click", ":checkbox", function () {
    var aVal = 0;
    var rtn = 0;
    var input_id = $(this).attr("id");

    if (input_id == "sch_user_chk_") {
      aVal = this.value;

      if ($(this).is(":checked")) {
        viewprmListExclude.push(aVal);
        ArrayRemove(viewprmList, aVal);
        makeviewprmList(viewprmList);
        makeviewprmListSelected(viewprmListExclude);
      }
    } else if (input_id == "users_selected") {
      aVal = this.value;

      if (!$(this).is(":checked")) {
        viewprmList.push(aVal);
        ArrayRemove(viewprmListExclude, aVal);
        makeviewprmList(viewprmList);
        makeviewprmListSelected(viewprmListExclude);
      }
    }
  });

  var SchChkAll = false;
  $("#sch_user_chk_all").click(function () {
    var obj = $("[name=sch_user_chk_]");
    var val = "";
    if (SchChkAll) {
      SchChkAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        viewprmListExclude.push(val);
        ArrayRemove(viewprmList, val);
      }

      makeviewprmList(viewprmList);
      makeviewprmListSelected(viewprmListExclude);
      SchChkAll = false;
    }
    $("#user_rec_chk_all").prop("checked", true);
  });

  var recCheckAll = false;
  $("#user_rec_chk_all").click(function () {
    var obj = $("[name=users_selected]");
    var val = "";
    if (recCheckAll) {
      recCheckAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        viewprmList.push(val);
        ArrayRemove(viewprmListExclude, val);
      }
      makeviewprmList(viewprmList);
      makeviewprmListSelected(viewprmListExclude);
      recCheckAll = false;
    }
    $("#sch_user_chk_all").prop("checked", false);
  });
});

function getAllItem() {
  var custField = "#settings_view_permission option";
  var options = $(custField);

  $(custField).each(function () {
    viewprmList.push(this.text + "|" + this.value);
  });
}

function getSelectedItem() {
  var custField = "#settings_view_permission option:selected";
  var options = $(custField);

  $(custField).each(function () {
    viewprmListExclude.push(this.text + "|" + this.value);
  });
}

function viewPermissionSave() {
  var custField = "#settings_view_permission";
  var arrayCust = [];

  $(custField + " > option").removeAttr("selected");

  var obj = $("[name=users_selected]");
  for (var i = 0; i < obj.length; i++) {
    if (obj[i].checked) {
      var strTemp = obj[i].value.split("|");
      arrayCust.push(String(strTemp[1]));
    }
  }
  $(custField).val(arrayCust);
}

function makeviewprmList(myJsArray) {
  var arg = $("#search-username-input").val();
  arg = arg.toLowerCase();
  var tempArray = myJsArray;
  tempArray.sort();
  if (arg) {
    tempArray = jQuery.grep(tempArray, function (n, i) {
      n = n.toLowerCase();
      return n.indexOf(arg) >= 0;
    });
  }
  $("#table_send tbody").remove();
  $.each(tempArray, function (index, item) {
    var strTemp = item.split("|");
    var tdInfo =
      "<input type='checkbox' name='sch_user_chk_' id='sch_user_chk_' value='" +
      item +
      "'>";
    $("#table_send").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(strTemp[0]))
      )
    );
  });
}

function makeviewprmListSelected(myJsArray) {
  var tempArray = myJsArray;
  $("#table_rec tbody").remove();
  $.each(tempArray, function (index, item) {
    var strTemp = item.split("|");
    var tdInfo =
      "<input type='checkbox' name='users_selected' id='users_selected' checked='checked' value='" +
      item +
      "'>";
    $("#table_rec").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(strTemp[0]))
      )
    );
  });
  var divdiv = document.getElementById("scrollDiv");
  divdiv.scrollTop = divdiv.scrollHeight;
}

function table_rec_insertRow(i) {
  var mytable = (contents = $("#table_rec")[0]);
  mytable.insertRow(i);
}

function ArrayRemove(arr, item) {
  for (var i = arr.length; i--; ) {
    if (arr[i] === item) {
      arr.splice(i, 1);
    }
  }
}
