var seletedItem = new Array();

$("#search-project-input").keyup(function () {
  var inputValue = $(this).val();
  if (inputValue.length < 1 && inputValue.length != 0) {
    return;
  } else {
    makeViewItem(projects);
  }
});

$("table").on("click", ":checkbox", function () {
  var aVal = 0;
  var clickId = $(this).attr("id");
  if (clickId == "select_projects") {
    if (myProjectCount <= $("#table_selected tr").length - 1) {
      messageProjectAlbeCount = messageProjectAlbeCount.replace(
        "%{count}",
        myProjectCount
      );
      alert(messageProjectAlbeCount);
      $(this).prop("checked", false);
      return;
    }
    aVal = this.value;
    if ($(this).is(":checked")) {
      projects = removeItem(projects, aVal);
    }
    $("#table_select tbody").remove();
    makeViewItem(projects);
  } else if (clickId == "selected_projects") {
    aVal = this.value;
    if (!$(this).is(":checked")) {
      seletedItem = jQuery.grep(seletedItem, function (value) {
        if (value.id == aVal) {
          projects.push(value);
        } else {
          return value;
        }
      });
      makeViewSelectedItem(seletedItem);
      makeViewItem(projects);
    }
    $("#projects_check_all").prop("checked", false);
  }
});

var checkAllInit = function (id) {
  var obj = $("[name=" + id + "]");
  var allChecked = true;
  if (obj.length == 0) allChecked = false;
  for (var i = 0; i < obj.length; i++) {
    if (obj[i].checked == false) allChecked = false;
  }
  if (id == "tracker_id") {
    if (allChecked == true) $("#trackers_check_all").prop("checked", true);
    if (allChecked == false) $("#trackers_check_all").prop("checked", false);
  } else if (id == "select_projects") {
    if (allChecked == true) $("#projects_check_all").prop("checked", true);
    if (allChecked == false) $("#projects_check_all").prop("checked", false);
  } else if (id == "selected_projects") {
    if (allChecked == true) $("#projects_checked_all").prop("checked", true);
    if (allChecked == false) $("#projects_checked_all").prop("checked", false);
  }
};

$("table").on("click", ":checkbox", function () {
  var clickId = $(this).attr("id");
  if (clickId == "tracker_id") checkAllInit("tracker_id");
  if (clickId == "tracker_id") checkAllInit("tracker_id");
  if (clickId == "select_projects") checkAllInit("selected_projects");
  if (clickId == "selected_projects") checkAllInit("selected_projects");
});

var makeViewItem = function (project) {
  var arg = $("#search-project-input").val();
  arg = arg.toLowerCase();
  project.sort();
  if (arg) {
    project = jQuery.grep(project, function (n, i) {
      if (n.project_name.toLowerCase().indexOf(arg) >= 0) return project;
    });
  }
  $("#table_select tbody").remove();
  $.each(project, function (i, item) {
    var tdInfo =
      "<input type='checkbox' name='select_projects' id='select_projects' value='" +
      item.id +
      "'>";
    $("#table_select").append(
      $("<tbody>").append(
        $("<tr>").append(
          $("<td>").append(tdInfo),
          $("<td>").append(item.project_name)
        )
      )
    );
  });
};

var makeViewSelectedItem = function (project) {
  $("#table_selected tbody").remove();
  $.each(project, function (i, item) {
    item = eval(item);
    var tdInfo =
      "<input type='checkbox' name='selected_projects' id='selected_projects' checked='checked' value='" +
      item.id +
      "'>";
    $("#table_selected").append(
      $("<tbody>").append(
        $("<tr>").append(
          $("<td>").append(tdInfo),
          $("<td>").append(item.project_name)
        )
      )
    );
  });
  var scrollDiv = document.getElementById("scroll_div");
  scrollDiv.scrollTop = scrollDiv.scrollHeight;
};

var removeItem = function (arr, item) {
  for (var i = arr.length; i--; ) {
    if (arr[i].id == item) {
      seletedItem.push({ id: arr[i].id, project_name: arr[i].project_name });
      arr.splice(i, 1);
      makeViewSelectedItem(seletedItem);
    }
  }
  return arr;
};

Chart.Legend.prototype.afterFit = function () {
  this.minSize.height = this.height = 70;
};
var getRandomColor = function () {
  var letters = "0123456789ABCDEF";
  var color = "#";
  for (var i = 0; i < 6; i++) {
    color += letters[Math.floor(Math.random() * 16)];
  }
  return color;
};

var createNewLegendAndAttach = function (chartInstance, legendOpts) {
  var legend = new Chart.NewLegend({
    ctx: chartInstance.chart.ctx,
    options: legendOpts,
    chart: chartInstance
  });

  if (chartInstance.legend) {
    Chart.layoutService.removeBox(chartInstance, chartInstance.legend);
    delete chartInstance.newLegend;
  }

  chartInstance.newLegend = legend;
  Chart.layoutService.addBox(chartInstance, legend);
};

var chartResize = function () {
  position = $("#chart_package").parents("div").parents("div").attr("id");
  chartLeftWidth = 0;
  chartCenterWidth = 0;
  chartRightWidth = 0;

  $("#chart_left").removeAttr("style");
  $("#chart_center").removeAttr("style");
  $("#chart_right").removeAttr("style");

  if ($("#chart_package").width() > 1006) {
    chartLeftWidth = Math.round($("#chart_package").width() / 3 - 5);
  } else {
    chartLeftWidth = $("#chart_package").width() - 5;
    $("#chart_left").css("border-right", "1px solid #cecece");
  }

  if ($("#chart_package").width() > 1006) {
    chartCenterWidth = Math.round($("#chart_package").width() / 3 - 5);
  } else {
    chartCenterWidth = $("#chart_package").width() - 5;
    $("#chart_center").css("border-top", "0px");
    $("#chart_center").css("border-right", "1px solid #cecece");
  }

  if ($("#chart_package").width() > 1006) {
    chartRightWidth = Math.round($("#chart_package").width() / 3 - 5);
  } else {
    chartRightWidth = $("#chart_package").width() - 5;
    $("#chart_right").css("border-top", "0px");
    $("#chart_right").css("border-right", "1px solid #cecece");
  }

  /*line chart*/
  $("#chart_left").css("width", chartLeftWidth);
  if (chartLeftWidth > 500) chartLeftWidth = 500;
  chartLeftHeight = Math.round(chartLeftWidth * 0.85);
  $("#line_chart").css("width", chartLeftWidth);
  $("#line_chart").css("height", chartLeftHeight);

  /*doughnut chart*/
  $("#chart_center").css("width", chartCenterWidth);
  if (chartCenterWidth > 400 && chartCenterWidth > 443) chartCenterWidth = 400;
  else chartCenterWidth = chartCenterWidth * 0.9;
  chartCenterHeight = Math.round(chartCenterWidth * 1.06);
  $("#doughnut_chart").css("width", chartCenterWidth);
  $("#doughnut_chart").css("height", chartCenterHeight);

  /*bar chart*/
  $("#chart_right").css("width", chartRightWidth);
  if (chartRightWidth > 400 && chartRightWidth > 443) chartRightWidth = 400;
  else chartRightWidth = chartRightWidth * 0.9;
  chartRightheight = Math.round(chartRightWidth * 1.06);
  $("#bar_chart").css("width", chartRightWidth);
  $("#bar_chart").css("height", chartRightheight);

  chartHeight = [
    Math.round($("#chart_left").height()),
    Math.round($("#chart_center").height()),
    Math.round($("#chart_right").height())
  ];
  maxHeight = Math.max.apply(null, chartHeight);
  $("#chart_left").css("height", maxHeight);
  $("#chart_center").css("height", maxHeight);
  $("#chart_right").css("height", maxHeight);
};

$(window).resize(function () {
  chartResize();
});

var viewSettingSave = function (viewType) {
  userId = $("#user_id").val();
  $.ajax({
    url: viewSettingUrl,
    type: "post",
    data: {
      view_type: viewType,
      user_id: userId,
      form_data: $("#selected_form").serialize()
    },
    dataType: "json"
  }).done(function (html) {
    mypageFlag = $("#mypage_flag").val();
    if (mypageFlag == "true") {
      $(location).attr("href", mypageUrl);
    } else {
      $(location).attr("href", userDashboardUrl);
    }
  });
};

var selectCheckAll = false;
var selectedList = new Array();
var selectList = new Array();

$("#projects_check_all").click(function () {
  var obj = $("[name=select_projects]");
  var val = "";
  if (!selectCheckAll) {
    if (
      myProjectCount <=
      $("#table_select tr").length - 1 + $("#table_selected tr").length - 1
    ) {
      messageProjectAlbeCount = messageProjectAlbeCount.replace(
        "%{count}",
        myProjectCount
      );
      alert(messageProjectAlbeCount);
      $(this).prop("checked", false);
      return;
    }
    for (var i = 0; i < obj.length; i++) {
      val = String(obj[i].value);
      projects = removeItem(projects, val);
    }
    $("#table_select tbody").remove();
    makeViewItem(projects);
    selectCheckAll = false;
  }
  $("#projects_checked_all").prop("checked", true);
});

var selectedCheckAll = false;
$("#projects_checked_all").click(function () {
  var obj = $("[name=selected_projects]");
  var val = "";
  if (selectedCheckAll) {
    selectedCheckAll = true;
  } else {
    projects = $.merge(projects, seletedItem);
    seletedItem = [];
    makeViewSelectedItem(seletedItem);
    makeViewItem(projects);
    selectedCheckAll = false;
  }
  $("#projects_checked_all").prop("checked", false);
  $("#projects_check_all").prop("checked", false);
});

$("#trackers_check_all").click(function () {
  var obj = $("[name=tracker_id]");
  var val = "";
  for (var i = 0; i < obj.length; i++) {
    if ($("input:checkbox[id='trackers_check_all']").is(":checked") == true)
      obj[i].checked = true;
    else obj[i].checked = false;
  }
});

var iframeResizeHeight = function (iframeObj) {
  var iframeHeight = iframeObj.contentWindow.document.body.scrollHeight;
  iframeObj.height = iframeHeight + 5;
};

function resizeIframe(gubun, dynHeight) {
  if (dynHeight <= 10) dynHeight += 90;
  else dynHeight += 50;

  if (gubun == "user_delay_issues")
    $("#user_delay_issues").css("height", dynHeight);
  else if (gubun == "user_imminent_issues")
    $("#user_imminent_issues").css("height", dynHeight);
}

function resizeProjectIframe(target, iframHeight) {
  if (iframHeight <= 10) iframHeight += 90;
  else iframHeight += 50;
  target = "#" + target;
  $(target).css("height", iframHeight);
}

function statusLineChart() {
  //line chart load
  var color = Chart.helpers.color;
  var lineChartData = {
    labels: USERDASHBOARD.data.progressTrackingPeriod,
    datasets: [
      {
        type: "line",
        lineTension: 0,
        label: USERDASHBOARD.label.barchartPlan,
        backgroundColor: color(window.chartColors.red).alpha(0.1).rgbString(),
        borderColor: window.chartColors.red,
        data: USERDASHBOARD.data.progressTrackingPlanValue
      },
      {
        type: "line",
        lineTension: 0,
        label: USERDASHBOARD.label.barchartCompleted,
        backgroundColor: color(window.chartColors.blue).alpha(0.1).rgbString(),
        borderColor: window.chartColors.blue,
        data: USERDASHBOARD.data.progressTrackingResultValue
      }
    ]
  };

  //line chart draw
  var lineCtx = document.getElementById("line_chart").getContext("2d");
  window.myLine = new Chart(lineCtx, {
    type: "line",
    data: lineChartData,
    options: {
      responsive: true,
      title: {
        display: true,
        fontSize: 14,
        text: USERDASHBOARD.label.linechartProgressTracking
      },
      layout: {
        padding: {
          left: 10,
          right: 10,
          top: 0,
          bottom: 0
        }
      },
      plugins: {
        datalabels: {
          align: function (context) {
            return "top";
          }
        }
      }
    }
  });
}

function statusDoughnutChart() {
  //doughnut chart config
  var config = {
    type: "doughnut",
    data: {
      datasets: [
        {
          data: USERDASHBOARD.data.persentStatus,
          backgroundColor: USERDASHBOARD.data.backgroundColor,
          borderColor: USERDASHBOARD.data.backgroundColor,
          label: "Dataset"
        }
      ],
      labels: USERDASHBOARD.data.statusNameCnt
    },
    options: {
      title: {
        display: true,
        fontSize: 14,
        text: USERDASHBOARD.label.doughnumchartProgressStatus
      },
      responsive: true
    }
  };

  //doughnut chart
  var doughnutCtx = document.getElementById("doughnut_chart").getContext("2d");
  window.myDoughnut = new Chart(doughnutCtx, config);
}

function progressBarChart() {
  //bar_chart load
  var barChartData = {
    datasets: [
      {
        label: USERDASHBOARD.label.barchartPlan,
        backgroundColor: window.chartColors.purple,
        stack: "Stack progress",
        data: [USERDASHBOARD.data.barPlanPercent, ""]
      },
      {
        label: USERDASHBOARD.label.barcharNormal,
        backgroundColor: window.chartColors.blue,
        stack: "Stack progress",
        data: ["", USERDASHBOARD.data.barTotalResultPercent]
      },
      {
        label: USERDASHBOARD.label.barcharDelay,
        backgroundColor: window.chartColors.red,
        stack: "Stack progress",
        data: ["", USERDASHBOARD.data.barDelayedPercent]
      }
    ],
    labels: [
      USERDASHBOARD.label.barchartPlan,
      USERDASHBOARD.label.barchartCompleted
    ]
  };

  //bar chart
  var barCtx = document.getElementById("bar_chart").getContext("2d");
  window.myBar = new Chart(barCtx, {
    type: "bar",
    data: barChartData,
    options: {
      title: {
        display: true,
        fontSize: 14,
        text: USERDASHBOARD.label.barchartDelayRatio
      },
      layout: {
        padding: {
          left: 0,
          right: 10,
          top: 0,
          bottom: 0
        }
      },
      responsive: true,
      scales: {
        xAxes: [
          {
            ticks: {
              beginAtZero: true
            }
          }
        ],
        yAxes: [
          {
            ticks: {
              beginAtZero: true
            }
          }
        ]
      }
    }
  });
}
