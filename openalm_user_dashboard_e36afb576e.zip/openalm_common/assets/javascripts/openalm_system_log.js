$(document).ready(function () {
  var thFieldError = $(".th_field_error").width();
  thFieldError = thFieldError + "px";
  $(".td_field_error").css("width", thFieldError);
  $(".td_field_error").css("overflow", "auto");

  var thFieldParam = $(".th_field_param").width();
  thFieldParam = thFieldParam + "px";
  $(".td_field_param").css("width", thFieldParam);
  $(".td_field_param").css("overflow", "auto");
});
