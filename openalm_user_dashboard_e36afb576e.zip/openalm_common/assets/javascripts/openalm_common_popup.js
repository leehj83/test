function showModalPopup(id, width, title) {
  var el = $("#" + id).first();
  if (el.length === 0 || el.is(":visible")) {
    return;
  }
  if (!title) title = el.find("h3.title").text();
  el.dialog({
    width: width,
    modal: true,
    resizable: false,
    dialogClass: "modal",
    zIndex: 825,
    title: title
  }).on("dialogclose", function () {
    $(".modal").remove();
  });
  $("#close_btn").focus();
}

function customfieldListPopup(target) {
  customfieldList = new Array();
  getAllItem(target);
  customfieldList = $(customfieldList).get();
  makeCustomfieldList(customfieldList);

  $("#search_customfield_input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) {
      return;
    }
    makeCustomfieldList(customfieldList);
  });
}

function makeCustomfieldList(myJsArray) {
  var arg = $("#search_customfield_input").val();
  arg = arg.toLowerCase();
  var tempArray = myJsArray;
  if (arg) {
    tempArray = jQuery.grep(tempArray, function (n, i) {
      n = n.toLowerCase();
      return n.indexOf(arg) >= 0;
    });
  }
  $("#table_send tbody").remove();
  $.each(tempArray, function (index, item) {
    if (item) {
      var tdInfo =
        "<a id='my_link' href='javascript:;' onclick='setCustomField();hideModal(this);'>" +
        item +
        "</a>";
      tdInfo = tdInfo.replace(
        "setCustomField()",
        'setCustomField("' + item + '")'
      );
      $("#table_send").append(
        $("<tbody>").append($("<tr>").append($("<td>").append(tdInfo)))
      );
    }
  });
}

function customfieldListMultiPopup(target) {
  customfieldList = new Array();
  customfieldListExclude = new Array();
  getAllItem(target);
  getSelectedItem(target);
  customfieldList = $(customfieldList).not(customfieldListExclude).get();
  makeCustomfieldListMulti(customfieldList);
  makeCustomfieldListSelected(customfieldListExclude);

  $("#search_customfield_input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) {
      return;
    }
    makeCustomfieldListMulti(customfieldList);
  });

  $("table").on("click", ":checkbox", function () {
    var aVal = 0;
    var input_id = $(this).attr("id");

    if (input_id == "sch_cust_chk_") {
      aVal = this.value;
      if ($(this).is(":checked")) {
        customfieldListExclude.push(aVal);
        ArrayRemove(customfieldList, aVal);
        makeCustomfieldListMulti(customfieldList);
        makeCustomfieldListSelected(customfieldListExclude);
        $("#cust_rec_chk_all").prop("checked", true);
      }
    } else if (input_id == "infosys_selected") {
      aVal = this.value;
      if (!$(this).is(":checked")) {
        customfieldList.push(aVal);
        ArrayRemove(customfieldListExclude, aVal);
        makeCustomfieldListMulti(customfieldList);
        makeCustomfieldListSelected(customfieldListExclude);
        $("#sch_cust_chk_all").prop("checked", false);
      }
    }
  });

  var schChkAll = false;
  $("#sch_cust_chk_all").click(function () {
    var obj = $("[name=sch_cust_chk_]");
    var val = "";
    if (schChkAll) {
      schChkAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        customfieldListExclude.push(val);
        ArrayRemove(customfieldList, val);
      }
      makeCustomfieldListMulti(customfieldList);
      makeCustomfieldListSelected(customfieldListExclude);
      schChkAll = false;
    }
    $("#cust_rec_chk_all").prop("checked", true);
  });

  var recCheckAll = false;
  $("#cust_rec_chk_all").click(function () {
    var obj = $("[name=infosys_selected]");
    var val = "";
    if (recCheckAll) {
      recCheckAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        customfieldList.push(val);
        ArrayRemove(customfieldListExclude, val);
      }
      makeCustomfieldListMulti(customfieldList);
      makeCustomfieldListSelected(customfieldListExclude);
      recCheckAll = false;
    }
    $("#sch_cust_chk_all").prop("checked", false);
  });
}

function userSelectPopup() {
  userSearch(userSelectListUrl, userData, userDataMe);

  var interval = null;
  $("#search_user_input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) return;
    clearTimeout(interval);
    interval = setTimeout(function () {
      $.ajax({
        url: userSelectListUrl,
        data: {
          user_name: edParam,
          user_id: userData,
          assigned_me: userDataMe
        },
        cache: false,
        success: function (html) {
          $("#user_div").html("");
          $("#user_div").append(html);
          if (edParam != "") $("#table_send").find("tr:eq(1)").remove();
        }
      });
    }, 300);
  });
}

function userSearch(userSelectListUrl, userData, userSearch) {
  $.ajax({
    url: userSelectListUrl,
    data: { user_name: "", user_id: userData, assigned_me: userDataMe },
    cache: false,
    success: function (html) {
      $("#user_div").html("");
      $("#user_div").append(html);
    }
  });
}

function userSelectSearch() {
  var interval = null;
  $("#search_user_input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) return;

    clearTimeout(interval);
    interval = setTimeout(function () {
      selectUserFilter(edParam);
    }, 300);
  });
}

function selectUserFilter(filter) {
  var filter, table, tr, td, cell, i, j;
  filter = filter.toUpperCase();

  table = document.getElementById("table_send");
  tr = table.getElementsByTagName("tr");
  for (i = 1; i < tr.length; i++) {
    tr[i].style.display = "none";
    td = tr[i].getElementsByTagName("td");
    for (var j = 0; j < td.length; j++) {
      cell = tr[i].getElementsByTagName("td")[j];
      if (cell) {
        if (cell.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
          break;
        }
      }
    }
  }
}

function userMultipleSelectPopup() {
  viewprmList = new Array();
  viewprmListExclude = new Array();
  getUserAllItem();
  getUserSelectedItem();
  viewprmList = $(viewprmList).not(viewprmListExclude).get();
  makeviewprmList(viewprmList);
  makeviewprmListSelected(viewprmListExclude);

  $("#search-username-input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) {
      return;
    }
    makeviewprmList(viewprmList);
  });

  $("table").on("click", ":checkbox", function () {
    var aVal = 0;
    var rtn = 0;
    var input_id = $(this).attr("id");

    if (input_id == "sch_user_chk_") {
      aVal = this.value;

      if ($(this).is(":checked")) {
        viewprmListExclude.push(aVal);
        ArrayRemove(viewprmList, aVal);
        makeviewprmList(viewprmList);
        makeviewprmListSelected(viewprmListExclude);
      }
    } else if (input_id == "users_selected") {
      aVal = this.value;
      if (!$(this).is(":checked")) {
        viewprmList.push(aVal);
        ArrayRemove(viewprmListExclude, aVal);
        makeviewprmList(viewprmList);
        makeviewprmListSelected(viewprmListExclude);
      }
    }
  });

  var schChkAll = false;
  $("#sch_user_chk_all").click(function () {
    var obj = $("[name=sch_user_chk_]");
    var val = "";
    if (schChkAll) {
      schChkAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        viewprmListExclude.push(val);
        ArrayRemove(viewprmList, val);
      }
      makeviewprmList(viewprmList);
      makeviewprmListSelected(viewprmListExclude);
      schChkAll = false;
    }
    $("#user_rec_chk_all").prop("checked", true);
  });

  var recCheckAll = false;
  $("#user_rec_chk_all").click(function () {
    var obj = $("[name=users_selected]");
    var val = "";
    if (recCheckAll) {
      recCheckAll = true;
    } else {
      for (var i = 0; i < obj.length; i++) {
        val = String(obj[i].value);
        viewprmList.push(val);
        ArrayRemove(viewprmListExclude, val);
      }
      makeviewprmList(viewprmList);
      makeviewprmListSelected(viewprmListExclude);
      recCheckAll = false;
    }
    $("#sch_user_chk_all").prop("checked", false);
  });
}

function getUserAllItem() {
  var custField = selectUserPopupTarget + " option";
  $(custField).each(function () {
    if (this.value > "") {
      viewprmList.push(this.text + "|" + this.value);
    }
  });
}

function getUserSelectedItem() {
  var custField = selectUserPopupTarget + " option:selected";
  $(custField).each(function () {
    viewprmListExclude.push(this.text + "|" + this.value);
  });
}

function viewPermissionSave() {
  var custField = selectUserPopupTarget;
  var arrayCust = [];
  $(custField + " > option").removeAttr("selected");

  var obj = $("[name=users_selected]");
  for (var i = 0; i < obj.length; i++) {
    if (obj[i].checked) {
      var strTemp = obj[i].value.split("|");
      arrayCust.push(String(strTemp[1]));
    }
  }
  $(custField).val(arrayCust);
}

function makeviewprmList(myJsArray) {
  var arg = $("#search-username-input").val();
  arg = arg.toLowerCase();
  var tempArray = myJsArray;
  /* tempArray.sort(); */
  if (arg) {
    tempArray = jQuery.grep(tempArray, function (n, i) {
      n = n.toLowerCase();
      return n.indexOf(arg) >= 0;
    });
  }
  $("#table_send tbody").remove();
  $.each(tempArray, function (index, item) {
    var strTemp = item.split("|");
    var tdInfo =
      "<input type='checkbox' name='sch_user_chk_' id='sch_user_chk_' value='" +
      item +
      "'>";
    $("#table_send").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(strTemp[0]))
      )
    );
  });
}

function makeviewprmListSelected(myJsArray) {
  var tempArray = myJsArray;
  $("#table_rec tbody").remove();
  $.each(tempArray, function (index, item) {
    var strTemp = item.split("|");
    var tdInfo =
      "<input type='checkbox' name='users_selected' id='users_selected' checked='checked' value='" +
      item +
      "'>";
    $("#table_rec").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(strTemp[0]))
      )
    );
  });
  var divdiv = document.getElementById("scroll_div");
  divdiv.scrollTop = divdiv.scrollHeight;
}

function ArrayRemove(arr, item) {
  for (var i = arr.length; i--; ) {
    if (arr[i] === item) {
      arr.splice(i, 1);
    }
  }
}

//_user_select_popup
function setUser(userId) {
  $(target).val(userId);
  $(target).change();
}

//_user_multi_select_popup
function getUserField(gubun, target) {
  var userData = new Array();
  var selectUserPopupTarget = target;

  var targetField = "";
  if (gubun == "select")
    targetField = selectUserPopupTarget + " option:selected";
  else targetField = selectUserPopupTarget + " option:not(:selected)";

  $(targetField).each(function () {
    if (
      this.value.length > 0 &&
      this.value != "none" &&
      this.value != "__none__"
    ) {
      userData.push(this.value);
    }
  });
  return userData.join(", ");
}

function userSelectMultiSearch() {
  var interval = null;
  $("#search-username-input").keyup(function () {
    var edParam = $(this).val();
    if (edParam.length < 1 && edParam.length != 0) return;

    clearTimeout(interval);
    interval = setTimeout(function () {
      unselectTableFilter(edParam);
    }, 300);
  });
}

function unselectTableFilter(filter) {
  var filter, table, tr, td, cell, i, j;
  filter = filter.toUpperCase();

  table = document.getElementById("table_send");
  tr = table.getElementsByTagName("tr");
  for (i = 1; i < tr.length; i++) {
    tr[i].style.display = "none";
    td = tr[i].getElementsByTagName("td");
    for (var j = 0; j < td.length; j++) {
      cell = tr[i].getElementsByTagName("td")[j];
      if (cell) {
        if (cell.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
          break;
        }
      }
    }
  }
}

function userMultiSelect(gubun, userSelectMultiListUrl, userData, userDataMe) {
  $.ajax({
    url: userSelectMultiListUrl,
    data: {
      select_gubun: gubun,
      user_name: "",
      user_id: userData,
      assigned_me: userDataMe
    },
    cache: false,
    success: function (html) {
      if (gubun == "select") {
        $("#selet_user_div").html("");
        $("#selet_user_div").append(html);
        userMultiReceivedClickEvent();
      } else {
        $("#unselect_user_div").html("");
        $("#unselect_user_div").append(html);
        userMultiSendClickEvent();
      }
    }
  });
}

function userMultiReceivedClickEvent() {
  $("#table_received").on("click", 'input[type="checkbox"]', function () {
    var input_id = $(this).attr("id");
    if (input_id != "unselect_chk_all") {
      var row = $(this).closest("tr").clone();
      $("#table_send tbody").append(row);
      $(this).closest("tr").remove();
      $("#select_chk_all").prop("checked", false);
    }
  });

  $("#unselect_chk_all").click(function () {
    $("#table_received tr").each(function (index) {
      if (index > 0) {
        var row = $(this).closest("tr").clone();
        $("#table_send tbody").append(row);
        $(this).closest("tr").remove();
        $("#select_chk_all").prop("checked", true);
      }
    });
    $("#table_send input[type=checkbox]").prop("checked", false);
  });
}

function userMultiSendClickEvent() {
  $("#table_send").on("click", 'input[type="checkbox"]', function () {
    var input_id = $(this).attr("id");
    if (input_id != "select_chk_all") {
      var row = $(this).closest("tr").clone();
      $("#table_received tbody").append(row);
      $(this).closest("tr").remove();
      $("#unselect_chk_all").prop("checked", true);
    }
  });

  $("#select_chk_all").click(function () {
    $("#table_send tr").each(function (index) {
      if (index > 0) {
        if ($(this).css("display") != "none") {
          var row = $(this).closest("tr").clone();
          $("#table_received tbody").append(row);
          $(this).closest("tr").remove();
        }
      }
    });
    $("#table_received input[type=checkbox]").prop("checked", true);
  });
}

function setUserMultiUser() {
  var arrayCust = [];
  $(target + " > option").removeAttr("selected");
  var obj = $("[name=info_user_selected]");
  for (var i = 0; i < obj.length; i++) {
    if (obj[i].checked) {
      arrayCust.push(String(obj[i].value));
    }
  }
  $(target).val(arrayCust);
  $(target).change();
}

//customfield_list_popup
function getAllItem(target) {
  var custField = target + " option";
  $(custField).each(function () {
    if (this.value != "__none__") customfieldList.push(this.value);
  });
}

function getSelectedItem(target) {
  var custField = target + " option:selected";

  $(custField).each(function () {
    if (this.value != "__none__") customfieldListExclude.push(this.value);
  });
}

function setCustMultiSelect() {
  var arrayCust = [];
  $(target + " > option").removeAttr("selected");
  var obj = $("[name=infosys_selected]");
  for (var i = 0; i < obj.length; i++) {
    if (obj[i].checked) {
      arrayCust.push(String(obj[i].value));
    }
  }
  $(target).val(arrayCust);
  $(target).change();
}

function setCustomField(customField) {
  customField = String(customField);
  $(target).val(customField);
  $(target).change();
}

function makeCustomfieldListMulti(myJsArray) {
  var arg = $("#search_customfield_input").val();
  arg = arg.toLowerCase();
  var tempArray = myJsArray;
  /* tempArray.sort(); */
  if (arg) {
    tempArray = jQuery.grep(tempArray, function (n, i) {
      n = n.toLowerCase();
      return n.indexOf(arg) >= 0;
    });
  }
  $("#table_send tbody").remove();
  $.each(tempArray, function (index, item) {
    var tdInfo =
      "<input type='checkbox' name='sch_cust_chk_' id='sch_cust_chk_' value='" +
      item +
      "'>";
    $("#table_send").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(item))
      )
    );
  });
}

function makeCustomfieldListSelected(myJsArray) {
  var tempArray = myJsArray;
  $("#table_rec tbody").remove();
  $.each(tempArray, function (index, item) {
    var tdInfo =
      "<input type='checkbox' name='infosys_selected' id='infosys_selected' checked='checked' value='" +
      item +
      "'>";
    $("#table_rec").append(
      $("<tbody>").append(
        $("<tr>").append($("<td>").append(tdInfo), $("<td>").append(item))
      )
    );
  });
  var divdiv = document.getElementById("scroll_div");
  divdiv.scrollTop = divdiv.scrollHeight;
}

function ArrayRemove(arr, item) {
  for (var i = arr.length; i--; ) {
    if (arr[i] === item) {
      arr.splice(i, 1);
    }
  }
}

function chkUserField(gubun, target) {
  var userData = new Array();
  var rtn = false;
  var selectUserPopupTarget = target;
  var targetField = selectUserPopupTarget + " option";

  $(targetField).each(function () {
    if (
      this.value.length > 0 &&
      this.value != "none" &&
      this.value != "__none__"
    ) {
      if (this.text == targetMeValue) rtn = true;
      else userData.push(this.value);
    }
  });

  if (gubun == "assignedToMe") return rtn;
  else {
    return userData.join(",");
  }
}

function getUserFieldMe(gubun) {
  var rtn = false;
  var selectUserPopupTarget = target;

  var targetField = "";
  if (gubun == "select")
    targetField = selectUserPopupTarget + " option:selected";
  else if (gubun == "unselect")
    targetField = selectUserPopupTarget + " option:not(:selected)";
  else targetField = selectUserPopupTarget + " option";

  $(targetField).each(function () {
    if (this.value.length > 0 && this.value != "none") {
      if (this.text == targetMeValue) {
        rtn = true;
      }
    }
  });
  return rtn;
}

function makeUserPopupLink(userPopupUrl, target, issue_id) {
  var userData = chkUserField("userData", target);
  if (userPopupUrl.indexOf("assigned_me") > 0)
    userPopupUrl +=
      "&target=" + target.replace(/#/gi, "") + "&user_id=" + userData;
  else
    userPopupUrl +=
      "?target=" + target.replace(/#/gi, "") + "&user_id=" + userData;
  userPopupUrl += "&issue_id=" + issue_id;
  if ($(target).attr("disabled") == "disabled")
    vLink = "&nbsp;<a class='icon icon-magnifier'></a>";
  else
    vLink =
      "&nbsp;<a class='icon icon-magnifier' data-remote='true' href='" +
      userPopupUrl +
      "'></a>";
  $(target).after(vLink);
}

function makeUserMultiPopupLink(userPopupUrl, target) {
  if ($(target).attr("disabled") == "disabled")
    vLink = "&nbsp;<a class='icon icon-magnifier icon-vertical-top'></a>";
  else {
    userPopupUrl += "&target=" + target.replace(/#/gi, "");
    vLink =
      "&nbsp;<a class='icon icon-magnifier icon-vertical-top' data-remote='true' href='" +
      userPopupUrl +
      "'></a>";
  }
  $(target).after(vLink);
}

function makeCustomPopupLink(customfieldPopupUrl, target) {
  if ($(target).attr("disabled") == "disabled")
    vLink = "&nbsp;<a class='icon icon-magnifier'></a>";
  else
    vLink =
      "&nbsp;<a class='icon icon-magnifier' data-remote='true' href='" +
      customfieldPopupUrl +
      "'></a>";
  $(target).after(vLink);
}

function makeCustomMultiPopupLink(customfieldPopupUrl, target) {
  if ($(target).attr("disabled") == "disabled")
    vLink = "&nbsp;<a class='icon icon-magnifier icon-vertical-top'></a>";
  else
    vLink =
      "&nbsp;<a class='icon icon-magnifier icon-vertical-top' data-remote='true' href='" +
      customfieldPopupUrl +
      "'></a>";
  $(target).after(vLink);
}
