function setEmailTempalte(statusId, emailId, emailName) {
  $("#email_template_id_" + statusId).val(emailId);
  $("#email_template_name_" + statusId).val(emailName);
  $("#email_template_enable_" + statusId).prop("checked", true);
}
