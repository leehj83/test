var dialogMessage = function (dialogId, message) {
  if (dialogId == "") dialogId = "dialog-message";
  $("#" + dialogId).html(message);
  $("#" + dialogId).dialog({
    modal: true,
    buttons: [
      {
        text: buttonClose,
        click: function () {
          $(this).dialog("close");
        }
      }
    ]
  });
};

var workflowChange = function () {
  workflowCenterElement = $(
    "[ aria-describedby = 'issue-dialog' ] .workflow-center:visible"
  );
  workflowElement = $(
    "[ aria-describedby = 'issue-dialog' ] .issue-workflow:visible"
  );
  if (workflowCenterElement.length > 0)
    workflowChangeApply(0, workflowCenterElement, workflowElement);
  workflowCenterElement = $(".attributes .workflow-center:visible");
  workflowElement = $(".attributes .issue-workflow:visible");
  if (workflowCenterElement.length > 0)
    workflowChangeApply(1, workflowCenterElement, workflowElement);
  workflowCenterElement = $(
    "#content > .new_issue #all_attributes .workflow-center:visible"
  );
  workflowElement = $(
    "#content > .new_issue #all_attributes .issue-workflow:visible"
  );
  if (workflowCenterElement.length > 0)
    workflowChangeApply(1, workflowCenterElement, workflowElement);
  workflowCenterElement = $("#update #all_attributes .workflow-center:visible");
  workflowElement = $("#update #all_attributes .issue-workflow:visible");
  if (workflowCenterElement.length > 0)
    workflowChangeApply(2, workflowCenterElement, workflowElement);
  workflowCenterElement = $(
    "#workflow > center > fieldset > .workflow-center:visible"
  );
  workflowElement = $(".issue-workflow:visible");
  if ($("#errorExplanation:visible").length > 0)
    workflowChangeApply(3, workflowCenterElement, workflowElement);
};

function workflowChangeApply(ii, workflowCenterElement, workflowElement) {
  arrowWidth = workflowCenterElement.find(".each-workflow").length * 117;
  workflowElement.css("overflow-x", "auto");
  if (workflowElement.width() < arrowWidth) {
    workflowCenterElement.width(arrowWidth);
    workflowCenterElement.parent().width(arrowWidth);
  } else {
    workflowCenterElement.width("");
    workflowCenterElement.parent().width("");
  }
  if (ii == 0) {
    if ($("#issue-form fieldset:visible").length > 1) {
      $("#all_attributes").width(
        $("#issue-form fieldset:visible:last").width()
      );
    } else {
      $("#all_attributes").width($("#issue-form .box").width() - 20);
    }
  } else if (ii == 2) {
    $("#all_attributes").width($("#issue-form .box").width() - 20);
  }

  if (
    typeof $("#update").attr("style") !== "undefined" &&
    $("#update").attr("style").match(/none/)
  ) {
    //in case of the edit button clicked
  } else {
    //==============Change icon=============================
    var issueStatusIdChildren = $("#issue_status_id").children();
    $(".each-workflow").each(function (j, elem) {
      existFlg = "no";
      issueStatusIdChildrenLength = issueStatusIdChildren.length;
      for (var i = 0; i < issueStatusIdChildrenLength; i++) {
        if (
          $(elem).find("text").text() ==
          $("#issue_status_id  option:selected").text()
        ) {
          existFlg = "selected";
        } else if (
          $(elem).find("text").text() == issueStatusIdChildren.eq(i).text()
        ) {
          existFlg = "yes";
        }
      }
      //=====Initialization of class=========
      $(elem)
        .removeClass("enable")
        .removeClass("workflow")
        .addClass("workflow");
      if (existFlg == "yes") {
        $(elem)
          .find("text")
          .css("text-decoration", "underline")
          .css("cursor", "pointer");
        $(elem).addClass("authorized_state");
      } else if (existFlg == "selected") {
        $(elem).find("text").css("text-decoration", "").css("cursor", "");
        $(elem).removeClass("authorized_state").addClass("workflow-enable");
      } else {
        $(elem).find("text").css("text-decoration", "").css("cursor", "");
        $(elem).removeClass("authorized_state");
      }
    });
  }
}

//==============when change, do=============================
var changeVisibility = function () {
  //==============Process to prevent duplicate execution=============================
  if (issueTrackerId != "") {
    if (
      issueTrackerId == $("#issue_tracker_id").val() &&
      issueStatusId == $("#issue_status_id").val()
    ) {
    } else {
      workflowChange();
    }
  } else {
    workflowChange();
  }
  issueTrackerId = $("#issue_tracker_id").val();
  issueStatusId = $("#issue_status_id").val();
};

function scoreCheck() {
  var min = 10;
  var max = 100;
  var normalScore = parseInt($("#settings_normal_score").val());
  var riskScore = parseInt($("#settings_risk_score").val());
  if (normalScore > max) {
    $("#settings_normal_score").focus();
    alert(messageMaxScoreError);
    return false;
  }
  if (normalScore < min) {
    $("#settings_normal_score").focus();
    alert(messageMinScoreError);
    return false;
  }
  if (riskScore > max) {
    $("#settings_risk_score").focus();
    alert(messageMaxScoreError);
    return false;
  }
  if (riskScore < min) {
    $("#settings_risk_score").focus();
    alert(messageMinScoreError);
    return false;
  }
  if (normalScore <= riskScore) {
    $("#settings_normal_score").focus();
    alert(messageNormalScoreError);
    return false;
  }
  if (riskScore >= normalScore) {
    $("#settings_risk_score").focus();
    alert(messageRiskScoreError);
    return false;
  }
}
