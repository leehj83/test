document.write('Hello, World!');
