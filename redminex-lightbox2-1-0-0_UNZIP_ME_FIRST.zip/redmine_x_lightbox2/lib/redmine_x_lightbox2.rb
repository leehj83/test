base_path = File.dirname(__FILE__)

require "#{base_path}/hooks/view_layouts_base_html_head_hook"
require "#{base_path}/patches/attachments_patch"